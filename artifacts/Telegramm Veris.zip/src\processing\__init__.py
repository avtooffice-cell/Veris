"""Article processing components."""
