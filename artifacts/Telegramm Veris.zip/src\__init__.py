"""Market Intelligence Telegram pipeline."""
